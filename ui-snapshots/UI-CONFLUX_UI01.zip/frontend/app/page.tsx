import type { Metadata } from "next";
import Landing from "@/components/Landing";
import "./landing.css";

export const metadata: Metadata = {
  title: "Conflux HQ — See the pattern. Follow it through.",
  description: "Bring customer complaints, payment evidence, and corrective actions into one workspace for bank operations.",
};

export default function Home() {
  return <Landing />;
}
