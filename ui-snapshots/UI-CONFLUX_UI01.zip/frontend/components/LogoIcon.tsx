/** Conflux HQ mark: chat bubble (orange) with a connected hub (navy). */
export default function LogoIcon({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 256 256" className={className} aria-label="Conflux HQ" role="img">
      <path fill="#E8651A" d="M62 66h140a20 20 0 0 1 20 20v90a20 20 0 0 1-20 20h-60l-44 38v-38H62a20 20 0 0 1-20-20V86a20 20 0 0 1 20-20z" />
      <g stroke="#14233F" strokeWidth="9" strokeLinecap="round" fill="#14233F">
        <path d="M128 30v200M30 128h196M128 128l74-80M128 128l62 62" fill="none" />
        <circle cx="128" cy="26" r="15" /><circle cx="30" cy="128" r="15" /><circle cx="226" cy="128" r="15" />
        <circle cx="128" cy="232" r="15" /><circle cx="204" cy="42" r="15" /><circle cx="192" cy="192" r="15" />
        <circle cx="128" cy="128" r="26" stroke="#F0F1EB" strokeWidth="6" />
      </g>
      <circle cx="128" cy="128" r="11" fill="#E8651A" />
    </svg>
  );
}
